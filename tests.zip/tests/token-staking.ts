import * as anchor from "@project-serum/anchor";
import { Program } from "@project-serum/anchor";
import { TokenStaking } from "../target/types/token_staking";

describe("token-staking", () => {
    // Configure the client to use the local cluster.
    anchor.setProvider(anchor.AnchorProvider.env());

    const program = anchor.workspace.TokenStaking as Program<TokenStaking>;

    it("Is initialized!", async () => {
        // Add your test here.
        const tx = await program.methods.updateVault({
            vestingPeriods: [
                {
                    duration: 0,
                    multiplier: 5
                }
            ]
        }).rpc();
        console.log("Your transaction signature", tx);
    });
});

let program: Program<TokenStaking> = {};

