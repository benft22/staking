use anchor_lang::error_code;

#[error_code]
pub enum TokenStakingError {
    NumericalError,
    
    VaultAuthorityMustSign,

    #[msg("Transaction must be signed by owner")]
    StakerPubkeyMismatch,

    #[msg("Vesting Period index must be less than defined vesting periods")]
    InvalidVestingPeriodIndex,

    #[msg("No token stakes have matured at the moment")]
    NoMaturedTokenStakes,

    #[msg("Token stake amount cannot be zero")]
    TokenStakeAmountCannotBeZero,
}
