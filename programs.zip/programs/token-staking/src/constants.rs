use anchor_lang::prelude::*;
use solana_program::pubkey;

pub const BENFT_TOKEN: Pubkey = pubkey!("BeNFTTK1zwAnDHTPmzGEnvfZzdWEBKZ1wt4BKkmKtXTv");

pub const VAULT_AUTHORITY: Pubkey = pubkey!("BeNFTTK1zwAnDHTPmzGEnvfZzdWEBKZ1wt4BKkmKtXTv");

pub const DISCRIMINATOR_LENGTH: usize = 8;
