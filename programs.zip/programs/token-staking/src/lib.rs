use anchor_lang::prelude::*;
use instructions::*;

pub mod constants;
pub mod errors;
pub mod instructions;
pub mod state;

declare_id!("Fg6PaFpoGXkYsidMpWTK6W2BeZ7FEfcYkg476zPFsLnS");

#[program]
pub mod token_staking {
    use super::*;

    pub fn update_vault(ctx: Context<UpdateVault>, vault_data: UpdateVaultData) -> Result<()> {
        update_vault::update_vault(ctx, vault_data)
    }

    pub fn stake_tokens(ctx: Context<StakeTokens>, token_stake_data: TokenStakeData) -> Result<()> {
        stake_tokens::stake_tokens(ctx, token_stake_data)
    }

    pub fn withdraw_tokens(
        ctx: Context<WithdrawTokens>,
        withdraw_data: WithdrawData,
    ) -> Result<()> {
        withdraw_tokens::withdraw_tokens(ctx, withdraw_data)
    }
}
