use anchor_lang::prelude::*;

#[account]
pub struct Staker {
    pub pubkey: Pubkey,
    pub token_stakes: Vec<TokenStake>,
}

impl Staker {
    pub const PREFIX: &'static [u8; 6] = b"staker";
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, Copy, PartialEq, Eq)]
pub struct TokenStake {
    pub amount: u64,
    pub timestamp: i64,
    pub vesting_period_index: u8,
}
