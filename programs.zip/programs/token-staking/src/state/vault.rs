use anchor_lang::prelude::*;

#[account]
pub struct Vault {
    pub authority: Pubkey,
    pub vesting_periods: Vec<VestingPeriod>,
}

impl Vault {
    pub const PREFIX: &'static [u8; 5] = b"vault";
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq, Eq)]
pub struct VestingPeriod {
    pub duration: i64,
    pub multiplier: u64,
}
