use std::mem::size_of_val;

use anchor_lang::{prelude::*, solana_program::clock::Clock};
use anchor_spl::{associated_token::*, token::*};

use crate::{
    constants::*,
    errors::TokenStakingError::*,
    state::{staker::*, vault::*},
};

#[derive(Accounts)]
#[instruction(vault_bump: u8, staker_bump: u8)]
pub struct WithdrawTokens<'info> {
    #[account(mut)]
    pub staker_wallet: Signer<'info>,

    #[account(seeds = [Vault::PREFIX], bump = vault_bump)]
    pub vault: Account<'info, Vault>,

    #[account(
        seeds = [Staker::PREFIX, staker_wallet.key.as_ref()],
        bump = staker_bump,
    )]
    pub staker: Account<'info, Staker>,

    #[account(mut, token::mint = BENFT_TOKEN)]
    pub recipient_token_account: Account<'info, TokenAccount>,

    #[account(
        mut, associated_token::mint = BENFT_TOKEN,
        associated_token::authority = vault
    )]
    pub vault_token_account: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub rent: Sysvar<'info, Rent>,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq, Eq)]
pub struct WithdrawData {
    indices: Vec<u8>,
}

pub fn withdraw_tokens(ctx: Context<WithdrawTokens>, withdraw_data: WithdrawData) -> Result<()> {
    let staker_wallet = &ctx.accounts.staker_wallet;
    let vault = &ctx.accounts.vault;
    let staker = &mut ctx.accounts.staker;
    let staker_account_info = staker.to_account_info();
    let recipient_token_account = &ctx.accounts.recipient_token_account;
    let vault_token_account = &ctx.accounts.vault_token_account;
    let token_program = &ctx.accounts.token_program;
    let rent = &ctx.accounts.rent;

    if staker.pubkey != *staker_wallet.key {
        return Err(StakerPubkeyMismatch.into());
    }

    let now = Clock::get()?.unix_timestamp;
    let mut transfer_amount = 0u64;

    // sort indices, then reverse them
    // this allows removing elements while traversing them
    let mut indices = withdraw_data.indices;
    indices.sort_unstable();
    indices.reverse();
    for token_stake_index in indices {
        let token_stake = staker.token_stakes[token_stake_index as usize];
        let vesting_period = &vault.vesting_periods[token_stake.vesting_period_index as usize];

        if now - token_stake.timestamp < vesting_period.duration {
            msg!(
                "warning: cannot withdraw token_stakes[{}]: lockup duration is {}s but only {}s have passed",
                token_stake_index,
                vesting_period.duration,
                now - token_stake.timestamp
            );
        } else {
            staker.token_stakes.remove(token_stake_index.into());
            transfer_amount += (token_stake.amount * vesting_period.multiplier) as u64;
        }
    }

    if transfer_amount == 0 {
        return Err(NoMaturedTokenStakes.into());
    }

    // return excess lamports to staker
    let mut account_lamports = staker_account_info.try_borrow_mut_lamports()?;
    let excess_lamports = if staker.token_stakes.len() > 0 {
        // if tokens are still staked, resize account
        let size = size_of_val(staker) + DISCRIMINATOR_LENGTH;
        staker_account_info.realloc(size, false)?;
        **account_lamports - rent.minimum_balance(size)
    } else {
        staker_account_info.realloc(0, false)?;
        **account_lamports
    };
    if excess_lamports > 0 {
        **account_lamports -= excess_lamports;
        **staker_wallet.to_account_info().try_borrow_mut_lamports()? += excess_lamports;
    }

    // transfer original + reward tokens
    transfer(
        CpiContext::new_with_signer(
            token_program.to_account_info(),
            Transfer {
                from: vault_token_account.to_account_info(),
                to: recipient_token_account.to_account_info(),
                authority: vault.to_account_info(),
            },
            &[&[Vault::PREFIX]],
        ),
        transfer_amount,
    )?;

    Ok(())
}
