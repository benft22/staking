use std::mem::{size_of, size_of_val};

use anchor_lang::{prelude::*, solana_program::clock::Clock};
use anchor_spl::{associated_token::*, token::*};

use crate::{
    constants::*,
    errors::TokenStakingError::*,
    state::{staker::*, vault::*},
};

#[derive(Accounts)]
#[instruction(vault_bump: u8)]
pub struct StakeTokens<'info> {
    #[account(mut)]
    pub staker_wallet: Signer<'info>,

    #[account(seeds = [Vault::PREFIX], bump = vault_bump)]
    pub vault: Account<'info, Vault>,

    #[account(
        init, payer = staker_wallet,
        space = size_of::<Staker>() + size_of::<TokenStake>(),
        seeds = [Staker::PREFIX, staker_wallet.key.as_ref()],
        bump
    )]
    pub staker: Account<'info, Staker>,

    #[account(mut, address = BENFT_TOKEN)]
    pub token_mint: Account<'info, Mint>,

    #[account(mut, token::mint = token_mint)]
    pub from_token_account: Account<'info, TokenAccount>,

    #[account(
        init, payer = staker_wallet,
        associated_token::mint = token_mint,
        associated_token::authority = vault
    )]
    pub vault_token_account: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub rent: Sysvar<'info, Rent>,
    pub system_program: Program<'info, System>,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq, Eq)]
pub struct TokenStakeData {
    amount: u64,
    vesting_period_index: u8,
}

pub fn stake_tokens(ctx: Context<StakeTokens>, token_stake_data: TokenStakeData) -> Result<()> {
    let staker_wallet = &ctx.accounts.staker_wallet;
    let vault = &mut ctx.accounts.vault;
    let staker = &mut ctx.accounts.staker;
    let from_token_account = &ctx.accounts.from_token_account;
    let vault_token_account = &ctx.accounts.vault_token_account;
    let token_program = &ctx.accounts.token_program;

    if staker.pubkey == Pubkey::default() {
        staker.pubkey = *staker_wallet.key;
    } else if staker.pubkey != *staker_wallet.key {
        return Err(StakerPubkeyMismatch.into());
    }

    let vesting_period_index = token_stake_data.vesting_period_index;
    if usize::from(vesting_period_index) >= vault.vesting_periods.len() {
        return Err(InvalidVestingPeriodIndex.into());
    }

    let amount = token_stake_data.amount;
    if amount == 0 {
        return Err(TokenStakeAmountCannotBeZero.into());
    }

    // resize staker account
    staker.token_stakes.push(TokenStake {
        amount,
        timestamp: Clock::get()?.unix_timestamp,
        vesting_period_index,
    });
    staker
        .to_account_info()
        .realloc(size_of_val(&staker) + DISCRIMINATOR_LENGTH, false)?;

    // transfer tokens
    transfer(
        CpiContext::new(
            token_program.to_account_info(),
            Transfer {
                from: from_token_account.to_account_info(),
                to: vault_token_account.to_account_info(),
                authority: staker_wallet.to_account_info(),
            },
        ),
        token_stake_data.amount,
    )?;

    Ok(())
}
