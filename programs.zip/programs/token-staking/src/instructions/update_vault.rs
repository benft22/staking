use std::mem::{size_of, size_of_val};

use anchor_lang::prelude::*;

use crate::{constants::*, errors::TokenStakingError::*, state::vault::*};

#[derive(Accounts)]
#[instruction(bump: u8)]
pub struct UpdateVault<'info> {
    #[account(mut, address = VAULT_AUTHORITY @ VaultAuthorityMustSign)]
    pub authority: Signer<'info>,

    #[account(
        init, payer = authority,
        space = size_of::<Vault>(),
        seeds = [Vault::PREFIX], bump
    )]
    pub vault: Account<'info, Vault>,

    pub associated_token_program: Program<'info, System>,
    pub system_program: Program<'info, System>,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq, Eq)]
pub struct UpdateVaultData {
    vesting_periods: Option<Vec<VestingPeriod>>,
}

pub fn update_vault(ctx: Context<UpdateVault>, vault_data: UpdateVaultData) -> Result<()> {
    let vault = &mut ctx.accounts.vault;
    let vault_account_info = vault.to_account_info();

    let new_vault_data_size = size_of_val(&vault_data) + DISCRIMINATOR_LENGTH;
    if vault_account_info.data_len() != new_vault_data_size {
        vault_account_info.realloc(new_vault_data_size, false)?;
    }

    if let Some(vesting_periods) = vault_data.vesting_periods {
        vault.vesting_periods = vesting_periods;
    }

    Ok(())
}
